for(var num = 0; num < 15; num++){
    console.log(num);
}
// Predict "0-14"
// Correct



for(var i = 1; i < 10; i+=2){
    if(i % 3 == 0){
        console.log(i);
    }
}
// Predict 3
// Answer = 3 & 9 (half right!)


for(var j = 1; j <= 15; j++){
    if(j % 2 == 0){
        j+=2;
    }
    else if(j % 3 == 0){
        j++;
    }
    console.log(j);
}
// Predict = 1,4,6,8,10,12,14,16
// Answer = 1,4,5,8,10,11,14,16