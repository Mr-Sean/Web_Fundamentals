// print odds
for(let i=0; i<20; i++){
    if(i % 2 !== 0)
    console.log(i);
}

// num and sum
var sum=0;
for(let i=0; i<5; i++){
    sum+=i
    console.log('num:', i, 'sum:', sum)
}